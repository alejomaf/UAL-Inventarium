<script>

insertCard($("#variableArea"), "images/essentials/inventario.png", null, null, {"Solicitudes pendientes":"location.hash='#solicitudes-objetos-pendientes';"},null);
insertCard($("#variableArea"), "images/essentials/inventario.png", null, null, {"Préstamos activos":"location.hash='#solicitudes-objetos-prestados';"},null);

</script>