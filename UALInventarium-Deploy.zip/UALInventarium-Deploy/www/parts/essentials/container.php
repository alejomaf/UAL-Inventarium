<div class="page-content p-5" id="content">
  <!-- Toggle button -->
<button id="sidebarCollapse" type="button" class="btn btn-light bg-white rounded-pill shadow-sm px-4 mb-4"><i class="fa fa-bars mr-2"></i><small class="text-uppercase font-weight-bold">Toggle</small></button>

<div id="variableArea" class="h-100 row justify-content-center">

</div>

</div>
