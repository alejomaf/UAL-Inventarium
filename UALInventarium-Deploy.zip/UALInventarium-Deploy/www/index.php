<?php session_start(); ?>
<?php include "connection/checkLoginUser.php"; ?>
<!DOCTYPE html>
<?php include "parts/essentials/head.html";?>

<body>
<?php include "parts/essentials/verticalNavBar.php"?>

<?php include "parts/essentials/container.php"?>

</body>
</html>
<script>cargarPagina();</script>